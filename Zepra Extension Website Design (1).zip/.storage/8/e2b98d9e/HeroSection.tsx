import { Button } from '@/components/ui/button';
import ZebraLogo from './ZebraLogo';

export default function HeroSection() {
  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden">
      <div className="container mx-auto px-6 text-center z-10">
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-1000">
          <ZebraLogo size="xl" className="mx-auto" />
          
          <div className="space-y-4">
            <h1 
              className="text-6xl md:text-8xl font-bold bg-gradient-to-r from-green-400 via-yellow-400 to-white bg-clip-text text-transparent animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-300"
              style={{
                textShadow: '0 0 30px rgba(0, 255, 0, 0.5), 0 0 60px rgba(255, 255, 0, 0.3)',
              }}
            >
              Master Your Workflow
            </h1>
            
            <p 
              className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-500"
              style={{
                textShadow: '0 0 20px rgba(255, 255, 255, 0.3)',
              }}
            >
              Zepra is the ultimate AI-powered assistant for automating survey tasks with next-level precision.
            </p>
          </div>

          <div className="animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-700">
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-green-500 to-yellow-500 hover:from-green-400 hover:to-yellow-400 text-black font-bold px-8 py-4 text-lg rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-green-500/25"
              style={{
                boxShadow: '0 0 30px rgba(0, 255, 0, 0.3), 0 0 60px rgba(255, 255, 0, 0.2)',
              }}
            >
              Get Started
            </Button>
          </div>
        </div>
      </div>

      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-green-400 rounded-full opacity-20 animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${3 + Math.random() * 4}s`,
            }}
          />
        ))}
      </div>
    </section>
  );
}